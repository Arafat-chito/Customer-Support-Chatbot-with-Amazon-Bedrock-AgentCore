import boto3
import main

client = boto3.client(
    "bedrock-agent-runtime",
    region_name=main.REGION,
)

response = client.retrieve(
    knowledgeBaseId=main.KB_ID,
    retrievalQuery={
        "text": "What is the battery life and return policy for Wireless Headphones Pro?"
    },
    retrievalConfiguration={
        "managedSearchConfiguration": {
            "numberOfResults": 3
        }
    },
)

results = response.get("retrievalResults", [])

print("Result count:", len(results))

for number, result in enumerate(results, start=1):
    print(f"\n--- Result {number} ---")
    print(result.get("content", {}).get("text", "No text returned"))
    print("Score:", result.get("score"))