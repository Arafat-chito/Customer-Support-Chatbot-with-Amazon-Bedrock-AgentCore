import main
import asyncio

payload = {
    "prompt": (
        "Use the browser tool to visit https://example.com. "
        "Tell me the page heading and what the page says the domain is for."
    ),
    "customer_id": "CUST-123",
    "session_id": "integration-browser-001",
}

loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)
response = loop.run_until_complete(main.invoke(payload))

print("\n--- Agent response ---")
print(response)