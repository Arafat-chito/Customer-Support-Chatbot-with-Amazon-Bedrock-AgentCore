"""
Customer Support AI Agent — Starter Code
==========================================
Your task is to complete this file by implementing all sections marked
with # TODO comments.

Reference the step-by-step solution files and INSTRUCTIONS.md for guidance.
Do NOT copy the solution directly — work through each section yourself.

Run locally (after filling in config values):
  uv run main.py '{"prompt": "Hello", "customer_id": "CUST-123", "session_id": "s1"}'

Deploy to AgentCore:
  agentcore deploy

Invoke deployed agent:
  agentcore invoke '{"prompt": "Hello", "customer_id": "CUST-123", "session_id": "s1"}'
"""

# ── Imports ───────────────────────────────────────────────────────────────────
# These imports are provided. Do not remove them.
from strands import Agent, tool
from bedrock_agentcore.runtime import BedrockAgentCoreApp
from bedrock_agentcore.memory import MemoryClient
from strands.models import BedrockModel
from strands.tools.mcp.mcp_client import MCPClient
import json
import os
import boto3
from strands.hooks import (
    HookProvider, AfterInvocationEvent, HookRegistry, MessageAddedEvent,
)
import logging
import uuid
from typing import Dict
from bedrock_agentcore.tools.code_interpreter_client import code_session
from strands_tools.browser import AgentCoreBrowser
def _prepare_playwright_driver() -> None:
    """Restore Playwright's executable after AgentCore strips its mode."""
    import os
    import shutil
    from pathlib import Path
    from playwright._impl import _driver, _transport

    node_path, cli_path = _driver.compute_driver_executable()

    if os.access(node_path, os.X_OK):
        return

    tmp_node = Path(f"/tmp/playwright-node-{os.getpid()}")
    shutil.copyfile(node_path, tmp_node)
    tmp_node.chmod(0o755)

    executable = (str(tmp_node), cli_path)
    _driver.compute_driver_executable = lambda: executable
    _transport.compute_driver_executable = lambda: executable


_prepare_playwright_driver()

logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger("CSAI_Agent")

# ── TODO 1 — App Initialisation ───────────────────────────────────────────────
app = BedrockAgentCoreApp()

# Suppress interactive tool-consent prompts (required in headless deployments).
os.environ["BYPASS_TOOL_CONSENT"] = "true"


# ── TODO 2 — Configuration ────────────────────────────────────────────────────
GATEWAY_URL = "https://customer-support-gateway-da2aiuzarc.gateway.bedrock-agentcore.us-east-1.amazonaws.com/mcp"
KB_ID       = "IGCW2RKYIP"
REGION      = "us-east-1"
MEMORY_ID   = "product_catalog_94v8i-4n7I7vGSuK"


# ── TODO 3 — Model and Clients ────────────────────────────────────────────────
model_id = "global.amazon.nova-2-lite-v1:0"

model = BedrockModel(model_id=model_id, region_name=REGION)
memory_client = MemoryClient(region_name=REGION)
_bedrock_runtime = boto3.client("bedrock-agent-runtime", region_name=REGION)


# ── TODO 4 — Namespace Helper ─────────────────────────────────────────────────
def _content_to_text(content) -> str:
    """Convert Strands content blocks or Memory content into plain text."""
    if isinstance(content, str):
        return content

    if isinstance(content, dict):
        return str(content.get("text", ""))

    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and block.get("text"):
                parts.append(str(block["text"]))
        return "\n".join(parts)

    return str(content or "")

def get_namespaces(
    mem_client: MemoryClient,
    memory_id: str,
) -> Dict:
    """Return strategy-type to namespace-template mappings."""
    try:
        strategies = mem_client.get_memory_strategies(memory_id)

        return {
            strategy["type"]: strategy["namespaces"][0]
            for strategy in strategies
            if strategy.get("type") and strategy.get("namespaces")
        }

    except Exception as e:
        logger.warning(f"Error fetching memory strategies: {e}")
        return {}

# ── TODO 5 — Memory Hook ──────────────────────────────────────────────────────
class MemoryHook(HookProvider):
    """Long-term memory hook for the customer support agent."""

    def __init__(
        self,
        actor_id: str,
        session_id: str,
        memory_client: MemoryClient,
        memory_id: str,
    ):
        self.actor_id = actor_id
        self.session_id = session_id
        self.memory_client = memory_client
        self.memory_id = memory_id
        self.namespaces = get_namespaces(memory_client, memory_id)

    def retrieve_customer_context(self, event: MessageAddedEvent):
        """Retrieve relevant memories and prepend them to the user message."""
        message = event.message

        if message.get("role") != "user":
            return

        query = _content_to_text(message.get("content", []))
        if not query:
            return

        collected_memories = []

        for strategy_type, namespace_template in self.namespaces.items():
            namespace = namespace_template.format(actorId=self.actor_id)

            try:
                memories = self.memory_client.retrieve_memories(
                    memory_id=self.memory_id,
                    namespace=namespace,
                    query=query,
                    top_k=5,
                )

                for memory in memories:
                    memory_text = _content_to_text(memory.get("content", {}))
                    if memory_text:
                        collected_memories.append(
                            f"[{strategy_type}] {memory_text}"
                        )

            except Exception as e:
                logger.warning(
                    f"Failed to retrieve memories from {namespace}: {e}"
                )

        if collected_memories:
            context = "\n".join(collected_memories)
            message["content"] = [
                {
                    "text": (
                        f"Customer Context:\n{context}\n\n"
                        f"Current customer request:\n{query}"
                    )
                }
            ]

    def save_support_interaction(self, event: AfterInvocationEvent):
        """Save the completed user and assistant turn to AgentCore Memory."""
        user_query = event.invocation_state.get("original_user_input")
        assistant_response = str(event.result) if event.result else ""

        if not user_query or not assistant_response:
            for message in reversed(event.agent.messages):
                role = message.get("role")
                text = _content_to_text(message.get("content", []))

                if role == "assistant" and not assistant_response and text:
                    assistant_response = text
                elif role == "user" and not user_query and text:
                    user_query = text

                if user_query and assistant_response:
                    break

        if not user_query or not assistant_response:
            logger.warning("No complete interaction was available to save.")
            return

        try:
            self.memory_client.create_event(
                memory_id=self.memory_id,
                actor_id=self.actor_id,
                session_id=self.session_id,
                messages=[
                    (user_query, "USER"),
                    (assistant_response, "ASSISTANT"),
                ],
            )
        except Exception as e:
            logger.warning(f"Failed to save interaction to memory: {e}")

    def register_hooks(self, registry: HookRegistry) -> None:  # type: ignore
        """Register both memory callbacks."""
        registry.add_callback(MessageAddedEvent, self.retrieve_customer_context)
        registry.add_callback(AfterInvocationEvent, self.save_support_interaction)


# ── TODO 6 — Knowledge Base Tool ─────────────────────────────────────────────
@tool
def search_knowledge_base(query: str) -> str:
    """
    Search the Amazon product catalog and support knowledge base.
    Use this for product specifications, return policies, warranty
    information, loyalty program details, and order status definitions.

    Args:
        query: The question or topic to search for

    Returns:
        Relevant information retrieved from the knowledge base
    """
    if not KB_ID or not KB_ID.strip():
        return (
            "Knowledge Base is not configured: KB_ID is empty or missing. "
            "Please configure KB_ID before attempting a knowledge-base search."
        )

    try:
        resp = _bedrock_runtime.retrieve(
            knowledgeBaseId=KB_ID,
            retrievalQuery={"text": query}
        )
        results = resp.get("retrievalResults", [])
        if not results:
            return "No relevant information found in the knowledge base."
        
        chunks = [r["content"]["text"] for r in results if "content" in r and "text" in r["content"]]
        return "\n---\n".join(chunks)
    except Exception as e:
        return f"Error querying Knowledge Base: {e}"


# ── TODO 7 — Loyalty Discount Tool (Code Interpreter) ────────────────────────
@tool
def calculate_loyalty_discount(
    loyalty_points: int,
    tier: str,
    order_total: float,
    product_category: str = "standard",
) -> str:
    """
    Calculate the loyalty discount for a customer order using the
    AgentCore Code Interpreter. Runs exact arithmetic in a secure sandbox.

    Args:
        loyalty_points:   Customer's current points balance
        tier:             Customer tier — Silver, Gold, or Platinum
        order_total:      Order total in USD
        product_category: standard, device, or fresh

    Returns:
        Full discount breakdown and final price
    """
    code = f"""
import json, math

earn_rates = {{"standard": 1, "device": 2, "fresh": 5}}
tier_rates = {{"Silver": 0.00, "Gold": 0.10, "Platinum": 0.15}}

pts = {loyalty_points}
tier = "{tier}"
total = {order_total}
cat = "{product_category}"

max_pts_allowed = math.floor((total * 0.50) * 100)
pts_to_use = min(pts, max_pts_allowed)
pts_redeemed = math.floor(pts_to_use / 500) * 500
pts_discount = pts_redeemed / 100.0

subtotal_after_pts = max(0.0, total - pts_discount)
t_rate = tier_rates.get(tier, 0.0)
tier_discount = subtotal_after_pts * t_rate

final_total = max(0.0, subtotal_after_pts - tier_discount)
total_savings = pts_discount + tier_discount
e_rate = earn_rates.get(cat, 1)
pts_earned = math.floor(final_total * e_rate)
remaining_pts = pts - pts_redeemed + pts_earned

result = {{
    "original_total": total,
    "points_redeemed": pts_redeemed,
    "points_discount_usd": pts_discount,
    "tier": tier,
    "tier_discount_usd": round(tier_discount, 2),
    "final_total_usd": round(final_total, 2),
    "total_savings_usd": round(total_savings, 2),
    "points_earned": pts_earned,
    "remaining_points": remaining_pts
}}
print(json.dumps(result))
"""

    try:
        with code_session(REGION) as session:
            response = session.invoke(
                "executeCode",
                {
                    "code": code,
                    "language": "python",
                    "clearContext": True,
                },
            )

            for event in response["stream"]:
                if "result" not in event:
                    continue

                result = event["result"]

                if result.get("isError"):
                    raise RuntimeError(
                        result.get("content", "Code Interpreter returned an error")
                    )

                stdout = result.get("structuredContent", {}).get("stdout")
                if stdout:
                    return stdout.strip()

                return json.dumps(result)

        raise RuntimeError("Code Interpreter returned no result")

    except Exception as e:
        logger.warning(f"Code interpreter failed, running fallback: {e}")

    # Fallback calculation
    t_rate = {"Silver": 0.0, "Gold": 0.10, "Platinum": 0.15}.get(tier, 0.0)
    tier_discount = round(order_total * t_rate, 2)
    final_total = round(order_total - tier_discount, 2)
    return json.dumps({
        "original_total": order_total,
        "tier": tier,
        "tier_discount_usd": tier_discount,
        "final_total_usd": final_total,
        "note": "Calculated via fallback (tier discount only)."
    })


# ── TODO 8 — Agent Entrypoint ─────────────────────────────────────────────────
@app.entrypoint
async def invoke(payload, context=None):
    """Handle one customer-support request in AgentCore Runtime."""
    user_input = payload.get("prompt", "").strip()
    actor_id = payload.get("customer_id", "ANONYMOUS")
    session_id = payload.get("session_id") or str(uuid.uuid4())

    if not user_input:
        return "Please provide a prompt."

    memory_hook = MemoryHook(
        actor_id=actor_id,
        session_id=session_id,
        memory_client=memory_client,
        memory_id=MEMORY_ID,
    )

    browser = AgentCoreBrowser(region=REGION)

    local_tools = [
        search_knowledge_base,
        calculate_loyalty_discount,
        browser.browser,
    ]

    try:
        mcp_client = MCPClient(url=GATEWAY_URL)

        # The MCP connection must remain open while the agent uses its tools.
        with mcp_client:
            try:
                gateway_tools = list(mcp_client.list_tools_sync())

                logger.info(
                    "Gateway connected successfully. Loaded %d tools: %s",
                    len(gateway_tools),
                    [gateway_tool.tool_name for gateway_tool in gateway_tools],
                )

            except TimeoutError:
                logger.exception("Gateway tool loading timed out")
                return (
                    "The customer-support Gateway timed out while loading tools. "
                    "Please try your request again shortly."
                )

            except ConnectionError:
                logger.exception("Gateway connection failed")
                return (
                    "The customer-support Gateway is temporarily unavailable. "
                    "Please try your request again shortly."
                )

            except Exception as exc:
                logger.exception("Gateway tool loading failed: %s", exc)
                return (
                    "The customer-support tools could not be loaded. "
                    "Please verify the Gateway configuration or try again later."
                )

            agent = Agent(
                model=model,
                tools=local_tools + gateway_tools,
                hooks=[memory_hook],
                system_prompt=(
                    "You are an accurate customer support assistant. "
                    "Use the knowledge base for product, policy, and loyalty questions. "
                    "Use Gateway tools to retrieve orders, customer profiles, and process refunds. "
                    "Before initiating a refund, retrieve the order so you can use its correct amount. "
                    "Use the loyalty calculator for discount arithmetic. "
                    "Use the browser when the customer requests live webpage information. "
                    "Never invent tool results."
                ),
            )

            response = await agent.invoke_async(
                user_input,
                invocation_state={"original_user_input": user_input},
            )
            return str(response)

    except TimeoutError:
        logger.exception("Gateway connection timed out")
        return (
            "The customer-support Gateway connection timed out. "
            "Please try your request again shortly."
        )

    except ConnectionError:
        logger.exception("Gateway connection failed")
        return (
            "The customer-support Gateway is temporarily unavailable. "
            "Please try your request again shortly."
        )

    except Exception as exc:
        logger.exception("Agent invocation failed: %s", exc)
        return (
            "The support agent could not complete your request because a service "
            "connection failed. Please try again later."
        )


if __name__ == "__main__":
    app.run()
