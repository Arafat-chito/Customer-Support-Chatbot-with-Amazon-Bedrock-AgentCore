import asyncio
import main

payload = {
    "prompt": (
        "Based only on what you remember about me, "
        "what communication method, product type, and color do I prefer?"
    ),
    "customer_id": "CUST-MEMORY-TEST",
    "session_id": "memory-read-002",
}

loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)
response = loop.run_until_complete(main.invoke(payload))

print("\n--- Memory write response ---")
print(response)