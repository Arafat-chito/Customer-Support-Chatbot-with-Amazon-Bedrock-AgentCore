import asyncio
import main


async def run_test():
    tool_use = {
        "toolUseId": "test-loyalty-001",
        "name": "calculate_loyalty_discount",
        "input": {
            "loyalty_points": 6000,
            "tier": "Platinum",
            "order_total": 100.00,
            "product_category": "standard",
        },
    }

    async for event in main.calculate_loyalty_discount.stream(
        tool_use,
        invocation_state={},
    ):
        print(event)


asyncio.run(run_test())