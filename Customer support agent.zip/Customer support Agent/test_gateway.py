import json
import main
from strands.tools.mcp.mcp_client import MCPClient

tool_name = "refund-processor-target___check_refund_status"

with MCPClient(url=main.GATEWAY_URL) as client:
    result = client.call_tool_sync(
        tool_use_id="test-order-001",
        name=tool_name,
        arguments={"refund_id": "REF-TEST123"},
    )

    print(json.dumps(result, indent=2, default=str))