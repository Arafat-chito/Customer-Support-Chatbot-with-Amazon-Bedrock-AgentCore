import subprocess

eval_command = [
    "python", "generate-eval-dataset.py",
    "--tests-json", "flow-tests-template.json",
    "--flow-id", "ABC1234567",
    "--flow-alias-id", "XYZ1234567",
    "--model-identifier", "us.amazon.nova-pro-v1:0",
    "--out-jsonl", "eval_dataset.jsonl"
]

print("Running evaluation dataset generation...")
subprocess.run(eval_command)